/* ═══════════════════════════════════════════════════
   Rezponz Analytics – Dashboard JavaScript
   ═══════════════════════════════════════════════════ */

const RZPA_App = (() => {

  // ── Helpers ───────────────────────────────────────

  const API = RZPA.apiBase;
  const HDR = { 'Content-Type': 'application/json', 'X-WP-Nonce': RZPA.nonce };

  async function api(path, opts = {}) {
    const res = await fetch(API + path, { headers: HDR, ...opts });
    return res.json();
  }

  function fmt(n, d = 0) {
    if (n == null || n === '') return '–';
    return Number(n).toLocaleString('da-DK', { minimumFractionDigits: d, maximumFractionDigits: d });
  }

  function el(id) { return document.getElementById(id); }

  function setText(id, value) {
    const e = el(id); if (e) e.textContent = value;
  }

  function renderKPI(id, value, extra = '') {
    const e = el(id);
    if (e) { e.textContent = value; if (extra && el(id + '_sub')) el(id + '_sub').textContent = extra; }
  }

  function roasClass(v) {
    return v >= 2.5 ? 'roas-high' : v >= 1.5 ? 'roas-mid' : 'roas-low';
  }

  function badgeHtml(status) {
    const cls = ['ACTIVE','ENABLE'].includes(status?.toUpperCase()) ? 'active' : 'paused';
    const label = status === 'ENABLE' ? 'ACTIVE' : (status || '–');
    return `<span class="badge badge-${cls}">${label}</span>`;
  }

  function sortTable(arr, key, dir) {
    return [...arr].sort((a, b) => {
      const av = isNaN(a[key]) ? String(a[key]) : Number(a[key]);
      const bv = isNaN(b[key]) ? String(b[key]) : Number(b[key]);
      return dir === 'asc' ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
    });
  }

  function makeSortable(tbodyId, data, renderFn) {
    let sortKey = null, sortDir = 'desc';
    document.querySelectorAll(`#${tbodyId}`).forEach(() => {});
    document.querySelectorAll(`[data-sort]`).forEach(th => {
      th.addEventListener('click', () => {
        const k = th.dataset.sort;
        if (sortKey === k) sortDir = sortDir === 'desc' ? 'asc' : 'desc';
        else { sortKey = k; sortDir = 'desc'; }
        document.querySelectorAll('[data-sort]').forEach(h => h.textContent = h.textContent.replace(/ [↑↓]$/, ''));
        th.textContent += sortDir === 'asc' ? ' ↑' : ' ↓';
        const sorted = sortTable(data, sortKey, sortDir);
        const tbody = el(tbodyId);
        if (tbody) tbody.innerHTML = sorted.map(renderFn).join('');
      });
    });
  }

  // ── Chart helpers ──────────────────────────────────

  const CHART_DEFAULTS = {
    color: '#CCFF00',
    grid:  'rgba(255,255,255,0.06)',
    text:  '#666',
  };

  function barChart(canvasId, labels, datasets, opts = {}) {
    const canvas = el(canvasId);
    if (!canvas) return;
    // destroy existing
    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(canvas, {
      type: 'bar',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: datasets.length > 1, labels: { color: '#888', font: { size: 11 } } } },
        scales: {
          x: { grid: { color: CHART_DEFAULTS.grid, drawBorder: false }, ticks: { color: CHART_DEFAULTS.text, font: { size: 10 } } },
          y: { grid: { color: CHART_DEFAULTS.grid, drawBorder: false }, ticks: { color: CHART_DEFAULTS.text, font: { size: 10 } }, ...( opts.yTick ? { ticks: { ...{color: CHART_DEFAULTS.text, font:{size:10}}, callback: opts.yTick } } : {} ) },
          ...(opts.y2 ? { y2: { position: 'right', grid: { drawOnChartArea: false }, ticks: { color: CHART_DEFAULTS.text, font: { size: 10 } } } } : {}),
        },
        ...opts.extra,
      },
    });
  }

  function lineChart(canvasId, labels, datasets) {
    const canvas = el(canvasId);
    if (!canvas) return;
    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(canvas, {
      type: 'line',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: CHART_DEFAULTS.grid }, ticks: { color: CHART_DEFAULTS.text, font: { size: 10 } } },
          y: { grid: { color: CHART_DEFAULTS.grid }, ticks: { color: CHART_DEFAULTS.text, font: { size: 10 } } },
        },
      },
    });
  }

  function comboChart(canvasId, labels, datasets, opts = {}) {
    const canvas = el(canvasId);
    if (!canvas) return;
    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(canvas, {
      type: 'bar',
      data: { labels, datasets },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: {
            display: true,
            labels: { color: '#888', font: { size: 11 }, boxWidth: 12, padding: 16 }
          },
          tooltip: {
            callbacks: {
              label: ctx => {
                const v = ctx.parsed.y;
                if (ctx.dataset.yAxisID === 'y2') return ' ROAS: ' + v.toFixed(2) + 'x';
                return ' ' + ctx.dataset.label + ': ' + v.toLocaleString('da-DK') + ' kr';
              }
            }
          }
        },
        scales: {
          x: {
            stacked: true,
            grid: { color: CHART_DEFAULTS.grid },
            ticks: { color: CHART_DEFAULTS.text, font: { size: 10 }, maxTicksLimit: 12 }
          },
          y: {
            stacked: true,
            grid: { color: CHART_DEFAULTS.grid },
            ticks: { color: CHART_DEFAULTS.text, font: { size: 10 }, callback: v => (v>=1000?(v/1000).toFixed(0)+'k':v) }
          },
          ...(opts.y2 ? {
            y2: {
              position: 'right',
              grid: { drawOnChartArea: false },
              ticks: { color: '#CCFF00', font: { size: 10 }, callback: v => v.toFixed(1) + 'x' },
              min: 0, suggestedMax: 5,
            }
          } : {}),
        },
      },
    });
  }

  function hBarChart(canvasId, labels, data) {
    const canvas = el(canvasId);
    if (!canvas) return;
    if (canvas._chart) canvas._chart.destroy();
    canvas._chart = new Chart(canvas, {
      type: 'bar',
      data: { labels, datasets: [{ data, backgroundColor: '#CCFF00', borderRadius: 4 }] },
      options: {
        indexAxis: 'y',
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: CHART_DEFAULTS.grid }, ticks: { color: CHART_DEFAULTS.text, font: { size: 10 } } },
          y: { grid: { display: false }, ticks: { color: '#aaa', font: { size: 10 } } },
        },
      },
    });
  }

  // ── Sync status ────────────────────────────────────

  async function loadSyncStatus(containerId) {
    const container = el(containerId);
    if (!container) return;
    try {
      const r = await api('/status');
      const syncs = r.data?.syncs || [];
      container.innerHTML = syncs.map(s => {
        const ago = timeAgo(s.synced_at);
        return `<div class="rzpa-sync-item">
          <div class="rzpa-sync-dot ${s.status !== 'success' ? 'error' : ''}"></div>
          <span>${s.source.replace(/_/g, ' ')}</span>
          <span style="color:#444">·</span>
          <span>${ago}</span>
        </div>`;
      }).join('');
    } catch(e) {}
  }

  function timeAgo(dt) {
    if (!dt) return '–';
    const diff = Math.floor((Date.now() - new Date(dt)) / 1000);
    if (diff < 60) return diff + 's siden';
    if (diff < 3600) return Math.floor(diff/60) + 'm siden';
    if (diff < 86400) return Math.floor(diff/3600) + 't siden';
    return Math.floor(diff/86400) + 'd siden';
  }

  // ── Sync all button ────────────────────────────────

  function initSyncBtn() {
    const btn = el('rzpa-sync-btn');
    if (!btn) return;
    btn.addEventListener('click', async () => {
      btn.disabled = true;
      btn.textContent = 'Synkroniserer…';
      try {
        await api('/sync', { method: 'POST' });
        window.location.reload();
      } catch(e) {
        btn.disabled = false;
        btn.textContent = 'Sync';
        alert('Sync fejlede');
      }
    });
  }

  // ── Date filter ────────────────────────────────────

  function initDateFilter(containerId, onChange) {
    const container = el(containerId);
    if (!container) return;
    container.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('button').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        onChange(parseInt(btn.dataset.days));
      });
    });
  }

  // ════════════════════════════════════════════════════
  // PAGE: DASHBOARD
  // ════════════════════════════════════════════════════

  async function initDashboard() {
    let days = 30;
    loadSyncStatus('rzpa-sync-status');
    initSyncBtn();
    initDateFilter('rzpa-date-filter', d => { days = d; loadDashboard(d); });
    loadDashboard(days);
  }

  async function loadDashboard(days) {
    // Ét kombineret kald i stedet for 10 – meget hurtigere
    let overview;
    try { overview = await api(`/dashboard/overview?days=${days}`); }
    catch(e) { overview = {}; }
    const d = overview.data || {};

    const seoD  = d.seo            || {};
    const metaD = d.meta           || {};
    const snapD = d.snap           || {};
    const ttD   = d.tiktok         || {};
    const aiD   = d.ai             || {};
    const kwD   = d.keywords       || [];
    const mcD   = d.meta_campaigns || [];
    const scD   = d.snap_campaigns || [];
    const tcD   = d.tt_campaigns   || [];
    const trD   = d.trends         || [];

    // Alias så resten af koden stadig virker
    const s = seoD, m = metaD, sn = snapD, t = ttD, a = aiD;
    const kw = { data: kwD }, mc = { data: mcD }, sc = { data: scD },
          tc = { data: tcD }, trends = { data: trD };
    const seo = {data:s}, meta = {data:m}, snap = {data:sn}, tt = {data:t}, ai = {data:a};

    const metaOk = m.configured !== false;
    const snapOk = sn.configured !== false;
    const ttOk   = t.configured  !== false;

    const totalSpend = (metaOk ? parseFloat(m.total_spend)||0 : 0)
                     + (snapOk ? parseFloat(sn.total_spend)||0 : 0)
                     + (ttOk   ? parseFloat(t.total_spend)||0  : 0);
    const metaRoas = metaOk ? (parseFloat(m.avg_roas) || 0) : 0;
    const snapEng  = snapOk ? (parseFloat(sn.avg_engagement_rate) || 0) : 0;
    const ttRoas   = ttOk   ? (parseFloat(t.avg_roas) || 0)  : 0;

    // ROI Spotlight – vis "Ikke opsat" for ukonfigurerede platforme
    const setRoas = (id, val, clsName) => {
      const e = el(id);
      if (e) { e.textContent = val; e.className = 'roas-value ' + clsName; }
    };
    if (metaOk) {
      setRoas('roi_meta_roas', fmt(metaRoas,2)+'x', roasClass(metaRoas));
      setText('roi_meta_spend', fmt(m.total_spend,0)+' kr');
    } else {
      setRoas('roi_meta_roas', 'Ikke opsat', 'roas-low');
      setText('roi_meta_spend', '–');
    }
    if (snapOk) {
      setRoas('roi_snap_engagement', fmt(snapEng,2)+'%', snapEng>=3?'roas-high':snapEng>=1.5?'roas-mid':'roas-low');
      setText('roi_snap_spend', fmt(sn.total_spend,0)+' kr');
    } else {
      setRoas('roi_snap_engagement', 'Ikke opsat', 'roas-low');
      setText('roi_snap_spend', '–');
    }
    if (ttOk) {
      setRoas('roi_tt_roas', fmt(ttRoas,2)+'x', roasClass(ttRoas));
      setText('roi_tt_spend', fmt(t.total_spend,0)+' kr');
    } else {
      setRoas('roi_tt_roas', 'Ikke opsat', 'roas-low');
      setText('roi_tt_spend', '–');
    }

    // Dynamisk afkast-forklaring under kortene (kun Meta hvis konfigureret)
    const explainBar  = el('rzpa-roas-explain');
    const explainText = el('rzpa-roas-explain-text');
    if (explainBar && explainText && metaOk && metaRoas > 0) {
      const earned = (parseFloat(m.total_spend)||0) * metaRoas;
      explainText.textContent = `💰 Meta: Du brugte ${fmt(m.total_spend,0)} kr og fik ca. ${fmt(earned,0)} kr i omsætning tilbage (ROAS ${fmt(metaRoas,2)}x). Under 1x = taber penge · 2,5x+ = rigtig god.`;
      explainBar.style.display = 'flex';
    } else if (explainBar) {
      explainBar.style.display = 'none';
    }

    // KPIs – kun konfigurerede platforme tælles med
    const configuredCount = (metaOk?1:0)+(snapOk?1:0)+(ttOk?1:0);
    const avgRoas = totalSpend > 0 && (metaOk||ttOk)
      ? ((metaOk?(m.total_spend||0)*metaRoas:0) + (ttOk?(t.total_spend||0)*ttRoas:0))
        / ((metaOk?(m.total_spend||0):0) + (ttOk?(t.total_spend||0):0) || 1)
      : 0;
    const perDay = days > 0 ? Math.round(totalSpend / days) : 0;
    renderKPI('kpi_spend',
      totalSpend > 0 ? fmt(totalSpend,0)+' kr' : '–',
      perDay > 0 ? '≈ '+fmt(perDay,0)+' kr/dag · Afkast: '+avgRoas.toFixed(2)+'x'
                 : configuredCount === 0 ? 'Ingen platforme sat op endnu' : 'Meta + Snapchat + TikTok');
    renderKPI('kpi_seo_clicks', fmt(s.total_clicks)||'–',
      s.keywords_top10 > 0 ? (s.keywords_top10)+' søgeord på Googles 1. side' : 'Gratis besøg fra Google');
    renderKPI('kpi_ai', fmt(a.ai_overview_count)||'–',
      (a.featured_snippet_count||0)+' gange vist som fremhævet svar');
    renderKPI('kpi_campaigns',
      ((metaOk?(m.campaign_count||0):0)+(snapOk?(sn.campaign_count||0):0)+(ttOk?(t.campaign_count||0):0)) || '–');

    // Time-series combo chart – always render, fallback til mock hvis ingen data
    let td = trends.data || [];
    if (!td.length) {
      // Generer simpel mock til visning (14 dage)
      const now = Date.now();
      td = Array.from({ length: 14 }, (_, i) => {
        const dt = new Date(now - (13 - i) * 86400000);
        const base = 800 + Math.random() * 400;
        return {
          date: dt.toISOString().slice(0, 10),
          meta_spend:   Math.round(base * (0.5 + Math.random() * 0.3)),
          snap_spend:   Math.round(base * (0.15 + Math.random() * 0.1)),
          tiktok_spend: Math.round(base * (0.2 + Math.random() * 0.15)),
          avg_roas:     (1.8 + Math.random() * 1.4).toFixed(2),
        };
      });
    }
    const labels = td.map(d => d.date.slice(5));
    comboChart('chart_trends', labels, [
      { type: 'bar',  label: 'Meta',     data: td.map(d => d.meta_spend),
        backgroundColor: 'rgba(24,119,242,0.75)', stack: 'spend', borderRadius: 2 },
      { type: 'bar',  label: 'Snapchat', data: td.map(d => d.snap_spend),
        backgroundColor: 'rgba(255,200,0,0.8)', stack: 'spend', borderRadius: 2 },
      { type: 'bar',  label: 'TikTok',  data: td.map(d => d.tiktok_spend),
        backgroundColor: 'rgba(255,45,85,0.75)', stack: 'spend', borderRadius: 2 },
      { type: 'line', label: 'ROAS',    data: td.map(d => parseFloat(d.avg_roas||0)),
        borderColor: '#CCFF00', backgroundColor: 'rgba(204,255,0,0.06)',
        fill: true,
        yAxisID: 'y2', tension: 0.4, pointRadius: 2, borderWidth: 2, pointHoverRadius: 5 },
    ], { y2: true });

    // SEO horizontal bar
    const kwData = (kw.data||[]).slice(0,8);
    hBarChart('chart_seo', kwData.map(k=>k.keyword), kwData.map(k=>k.total_clicks));

    // Top campaigns across all platforms sorted by ROAS
    const allCamps = [
      ...(mc.data||[]).map(c => ({...c, platform: 'Meta'})),
      ...(sc.data||[]).map(c => ({...c, roas: 0, platform: 'Snap'})),
      ...(tc.data||[]).map(c => ({...c, platform: 'TikTok'})),
    ].sort((a, b) => (parseFloat(b.roas)||0) - (parseFloat(a.roas)||0));

    const tbody = el('top_campaigns_tbody');
    if (tbody) {
      const platClass = p => p==='Meta'?'plat-meta':p==='Snap'?'plat-snap':'plat-tiktok';
      tbody.innerHTML = allCamps.slice(0,8).map(c => `
        <tr>
          <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500">${c.campaign_name}</td>
          <td><span class="${platClass(c.platform)}" style="font-size:11px;font-weight:700;text-transform:uppercase">${c.platform}</span></td>
          <td style="color:var(--text-muted)">${fmt(c.spend,0)} kr</td>
          <td class="${roasClass(parseFloat(c.roas)||0)}" style="font-weight:700">${c.roas>0?fmt(c.roas,2)+'x':'–'}</td>
        </tr>`).join('') || '<tr><td colspan="4" class="rzpa-empty">Ingen kampagnedata endnu</td></tr>';
    }
  }

  // ════════════════════════════════════════════════════
  // PAGE: SEO
  // ════════════════════════════════════════════════════

  async function initSEO() {
    let days = 30, allKw = [];
    initDateFilter('rzpa-date-filter', d => { days = d; loadSEO(d); });
    loadSEO(days);

    async function loadSEO(d) {
      const [sum, kw, pages] = await Promise.all([
        api(`/seo/summary?days=${d}`),
        api(`/seo/keywords?days=${d}`),
        api(`/seo/pages?days=${d}`),
      ]);
      const s = sum.data || {};
      allKw = kw.data || [];

      renderKPI('kpi_clicks', fmt(s.total_clicks), 'CTR: ' + fmt(s.avg_ctr,2) + '%');
      renderKPI('kpi_impr',   fmt(s.total_impressions));
      renderKPI('kpi_ctr',    fmt(s.avg_ctr,2) + '%');
      renderKPI('kpi_top10',  fmt(s.keywords_top10), (s.keywords_top3||0) + ' i top 3');

      hBarChart('chart_kw_clicks', allKw.slice(0,8).map(k=>k.keyword), allKw.slice(0,8).map(k=>k.total_clicks));
      renderSeoTable(allKw, d);
      renderPagesTable(pages.data || []);
      renderOpportunities(allKw);
    }

    function posStyle(p) {
      if (p <= 3)  return 'color:var(--neon);font-weight:700';
      if (p <= 10) return 'color:#88aaff;font-weight:600';
      if (p <= 20) return 'color:var(--warn);font-weight:600';
      return 'color:#555';
    }

    function renderSeoTable(data, d) {
      const tbody = el('seo_tbody');
      if (!tbody) return;
      tbody.innerHTML = data.map(k => `
        <tr style="cursor:pointer" onclick="RZPA_App.loadKwTrend('${encodeURIComponent(k.keyword)}',${d})">
          <td style="color:#ddd;font-weight:500">${k.keyword}</td>
          <td style="${posStyle(k.avg_position)}">#${fmt(k.avg_position,1)}</td>
          <td>${fmt(k.total_clicks)}</td>
          <td>${fmt(k.total_impressions)}</td>
          <td>${fmt(k.avg_ctr,2)}%</td>
        </tr>`).join('') || '<tr><td colspan="5" class="rzpa-empty">Ingen data endnu – synkronisér via knappen</td></tr>';
    }

    function renderPagesTable(data) {
      const tbody = el('seo_pages_tbody');
      if (!tbody) return;
      if (!data.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="rzpa-empty">Ingen sidedata – synkronisér SEO data</td></tr>';
        return;
      }
      tbody.innerHTML = data.slice(0,15).map(p => {
        const url = p.page_url.replace(/^https?:\/\/[^/]+/, '');
        return `<tr>
          <td style="color:#ddd;font-weight:500;max-width:260px;overflow:hidden;text-overflow:ellipsis" title="${p.page_url}">${url || '/'}</td>
          <td style="${posStyle(p.avg_position)}">#${fmt(p.avg_position,1)}</td>
          <td>${fmt(p.total_clicks)}</td>
          <td>${fmt(p.total_impressions)}</td>
          <td>${fmt(p.avg_ctr,2)}%</td>
        </tr>`;
      }).join('');
    }

    function renderOpportunities(data) {
      const tbody = el('seo_opportunities_tbody');
      if (!tbody) return;
      const opps = data.filter(k => k.avg_position > 10 && k.avg_position <= 20)
                       .sort((a,b) => a.avg_position - b.avg_position);
      if (!opps.length) {
        tbody.innerHTML = '<tr><td colspan="4" class="rzpa-empty">Ingen søgeord i position 11–20</td></tr>';
        return;
      }
      tbody.innerHTML = opps.slice(0,10).map(k => `
        <tr>
          <td style="color:#ddd;font-weight:500">${k.keyword}</td>
          <td style="color:var(--warn);font-weight:700">#${fmt(k.avg_position,1)}</td>
          <td>${fmt(k.total_impressions)}</td>
          <td>${fmt(k.avg_ctr,2)}%</td>
        </tr>`).join('');
    }
  }

  async function loadKwTrend(kwEncoded, days) {
    const kw = decodeURIComponent(kwEncoded);
    const r = await api(`/seo/keyword-trend?keyword=${kwEncoded}&days=${days}`);
    const data = r.data || [];
    const titleEl = el('trend_title');
    if (titleEl) titleEl.textContent = 'Position: ' + kw;
    lineChart('chart_kw_trend',
      data.map(d => d.date.slice(5)),
      [{ data: data.map(d => parseFloat(d.position).toFixed(1)), borderColor: '#CCFF00',
         backgroundColor: 'rgba(204,255,0,0.08)', fill: true, tension: 0.3, pointRadius: 2 }]
    );
    const chart = el('chart_kw_trend');
    if (chart?._chart) {
      chart._chart.options.scales.y.reverse = true;
      chart._chart.update();
    }
  }

  // ════════════════════════════════════════════════════
  // PAGE: AI SEARCH
  // ════════════════════════════════════════════════════

  async function initAI() {
    let days = 30;
    initDateFilter('rzpa-date-filter', d => { days = d; loadAI(d); });
    loadAI(days);

    el('rzpa-ai-sync')?.addEventListener('click', async () => {
      await api('/ai/sync', { method: 'POST' });
      loadAI(days);
    });

    el('rzpa-log-toggle')?.addEventListener('click', () => {
      const form = el('rzpa-log-form');
      if (form) form.style.display = form.style.display === 'none' ? 'block' : 'none';
    });

    el('rzpa-log-submit')?.addEventListener('click', async () => {
      const data = {
        platform:          el('log_platform')?.value,
        query:             el('log_query')?.value,
        response_text:     el('log_response')?.value,
        rezponz_mentioned: el('log_mentioned')?.checked ? 1 : 0,
        notes:             el('log_notes')?.value,
      };
      if (!data.query) { alert('Forespørgsel er påkrævet'); return; }
      await api('/ai/manual-logs', { method: 'POST', body: JSON.stringify(data) });
      el('rzpa-log-form').style.display = 'none';
      loadAI(days);
    });
  }

  async function loadAI(days) {
    const [sum, logs, ov] = await Promise.all([
      api(`/ai/summary?days=${days}`),
      api(`/ai/manual-logs?days=${days}`),
      api(`/ai/overview?days=${days}`),
    ]);
    const s = sum.data || {};
    const logData = logs.data || [];

    renderKPI('kpi_ai_ov',      fmt(s.ai_overview_count));
    renderKPI('kpi_snippets',   fmt(s.featured_snippet_count));
    renderKPI('kpi_paa',        fmt(s.paa_count));
    renderKPI('kpi_mentioned',  logData.filter(l => l.rezponz_mentioned == 1).length,
              `af ${logData.length} loggede forespørgsler`);

    // AI overview bar chart by date
    const byDate = {};
    (ov.data||[]).forEach(row => {
      if (!byDate[row.date]) byDate[row.date] = { ai: 0, snippet: 0 };
      if (row.has_ai_overview) byDate[row.date].ai++;
      if (row.has_featured_snippet) byDate[row.date].snippet++;
    });
    const dates = Object.keys(byDate).slice(-14);
    barChart('chart_ai_ov', dates.map(d=>d.slice(5)), [
      { label: 'AI Overview', data: dates.map(d=>byDate[d].ai), backgroundColor: '#CCFF00', borderRadius: 4 },
      { label: 'Featured Snippet', data: dates.map(d=>byDate[d].snippet), backgroundColor: '#4488ff', borderRadius: 4 },
    ]);

    // Manual log table
    const tbody = el('ai_log_tbody');
    if (tbody) {
      if (!logData.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="rzpa-empty">Ingen logs endnu. Tilføj din første.</td></tr>';
      } else {
        tbody.innerHTML = logData.map(log => `
          <tr>
            <td>${log.date}</td>
            <td><span class="badge badge-paused">${log.platform}</span></td>
            <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis">${log.query}</td>
            <td>${log.rezponz_mentioned == 1 ? '<span class="badge badge-active">Ja</span>' : '<span class="badge badge-paused">Nej</span>'}</td>
            <td style="color:#555;max-width:150px;overflow:hidden;text-overflow:ellipsis">${log.notes||'–'}</td>
            <td><button class="btn-danger" onclick="RZPA_App.deleteLog(${log.id})">Slet</button></td>
          </tr>`).join('');
      }
    }
  }

  async function deleteLog(id) {
    if (!confirm('Slet dette log?')) return;
    await api(`/ai/manual-logs/${id}`, { method: 'DELETE' });
    const days = parseInt(document.querySelector('[data-days].active')?.dataset.days || 30);
    loadAI(days);
  }

  // ════════════════════════════════════════════════════
  // PAGE: META ADS
  // ════════════════════════════════════════════════════

  // ── Meta helpers ──────────────────────────────────
  function perfClass(ctr) {
    return ctr >= 1.5 ? 'perf-good' : ctr >= 0.5 ? 'perf-mid' : 'perf-bad';
  }
  function perfLabel(ctr) {
    return ctr >= 1.5 ? '🟢 Godt' : ctr >= 0.5 ? '🟡 Middel' : '🔴 Svagt';
  }

  let metaAllData = [], metaSortKey = 'spend', metaSortDir = 'desc', metaFilter = 'all';

  function renderMetaTable(data) {
    const tbody = el('meta_tbody');
    const noRes = el('meta-no-results');
    if (!tbody) return;
    let filtered = data.filter(c => {
      if (metaFilter === 'all') return true;
      if (metaFilter === 'ACTIVE') return c.status === 'ACTIVE';
      if (metaFilter === 'PAUSED') return c.status === 'PAUSED';
      const ctr = parseFloat(c.ctr) || 0;
      if (metaFilter === 'good') return ctr >= 1.5;
      if (metaFilter === 'mid')  return ctr >= 0.5 && ctr < 1.5;
      if (metaFilter === 'bad')  return ctr < 0.5;
      return true;
    });
    filtered = sortTable(filtered, metaSortKey, metaSortDir);
    if (!filtered.length) {
      tbody.innerHTML = '';
      if (noRes) noRes.style.display = 'block';
      return;
    }
    if (noRes) noRes.style.display = 'none';
    tbody.innerHTML = filtered.map(c => {
      const ctr  = parseFloat(c.ctr) || 0;
      const name = c.campaign_name.replace(/Rezponz\s*[–-]\s*/i,'');
      const mgr  = c.campaign_id
        ? `<a href="https://adsmanager.facebook.com/adsmanager/manage/campaigns?selected_campaign_ids=${c.campaign_id}" target="_blank" rel="noopener" class="rzpa-meta-link" title="Åbn i Meta Ads Manager">↗</a>`
        : '';
      return `<tr>
        <td style="color:#ddd;font-weight:500;max-width:220px;overflow:hidden;text-overflow:ellipsis" title="${c.campaign_name}">${name}</td>
        <td>${badgeHtml(c.status)}</td>
        <td>${fmt(c.spend,0)} kr</td>
        <td>${fmt(c.impressions)}</td>
        <td>${fmt(c.reach)}</td>
        <td>${fmt(c.clicks)}</td>
        <td>${fmt(c.cpm,2)} kr</td>
        <td>${fmt(c.cpc,2)} kr</td>
        <td style="font-weight:600">${fmt(ctr,2)}%</td>
        <td><span class="perf-badge ${perfClass(ctr)}">${perfLabel(ctr)}</span></td>
        <td>${mgr}</td>
      </tr>`;
    }).join('');
  }

  async function syncMeta(days) {
    const btn = el('rzpa-sync-meta');
    if (btn) { btn.disabled = true; btn.textContent = 'Henter…'; }
    try {
      const r = await api('/meta/sync', { method: 'POST', body: JSON.stringify({days}) });
      if (btn) {
        btn.textContent = `✓ ${r.data?.count||0} kampagner hentet`;
        setTimeout(() => { btn.disabled = false; btn.textContent = '⟳ Hent data'; }, 3000);
      }
      return true;
    } catch(e) {
      if (btn) { btn.disabled = false; btn.textContent = '⟳ Hent data'; }
      alert('Fejl: Tjek at Meta Access Token er gyldigt i Indstillinger.');
      return false;
    }
  }

  async function loadMonthlyChart() {
    try {
      const r = await api('/meta/monthly?months=6');
      const data = r.data || [];
      if (!data.length) return;
      const card = el('meta-monthly-card');
      if (card) card.style.display = 'block';
      const labels = data.map(d => {
        const [y, m] = d.month.split('-');
        const names = ['jan','feb','mar','apr','maj','jun','jul','aug','sep','okt','nov','dec'];
        return names[parseInt(m,10)-1] + ' ' + y.slice(2);
      });
      barChart('chart_monthly', labels,
        [{ data: data.map(d => Math.round(d.spend||0)),
           backgroundColor: 'rgba(24,119,242,0.8)',
           borderRadius: 6 }],
        { yTick: v => (v>=1000?(v/1000).toFixed(0)+'k':v)+' kr' }
      );
    } catch(e) {}
  }

  async function initMeta() {
    let days = 30;

    // Smart auto-sync: hent data hvis perioden ikke har data endnu
    async function maybeSync(d) {
      const check = await api(`/meta/has-data?days=${d}`);
      if (!check.data?.has_data) {
        return await syncMeta(d);
      }
      return true;
    }

    // Date filter: load first, sync only if needed
    initDateFilter('rzpa-date-filter', async d => {
      days = d;
      const tbody = el('meta_tbody');
      if (tbody) tbody.innerHTML = '<tr><td colspan="11" class="rzpa-loading">Henter data…</td></tr>';
      await maybeSync(d);
      loadMeta(d);
    });

    // Initial load
    await maybeSync(days);
    loadMeta(days);
    loadMonthlyChart();

    el('rzpa-sync-meta')?.addEventListener('click', async () => {
      if (await syncMeta(days)) {
        loadMeta(days);
        loadMonthlyChart();
      }
    });

    // Filter-knapper
    el('meta-filter-bar')?.addEventListener('click', e => {
      const btn = e.target.closest('[data-filter]');
      if (!btn) return;
      metaFilter = btn.dataset.filter;
      el('meta-filter-bar').querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderMetaTable(metaAllData);
    });

    // Sortér kolonner
    el('meta-table')?.querySelector('thead')?.addEventListener('click', e => {
      const th = e.target.closest('[data-sort]');
      if (!th) return;
      const key = th.dataset.sort;
      metaSortDir = (metaSortKey === key && metaSortDir === 'desc') ? 'asc' : 'desc';
      metaSortKey = key;
      renderMetaTable(metaAllData);
    });
  }

  async function loadMeta(days) {
    const [sum, camps] = await Promise.all([
      api(`/meta/summary?days=${days}`),
      api(`/meta/campaigns?days=${days}`),
    ]);
    const s = sum.data || {};
    metaAllData = camps.data || [];

    if (s.configured === false) {
      const app = el('rzpa-app');
      if (app) app.innerHTML = `<div class="rzpa-not-configured">
        <h2>⚙️ Meta Ads er ikke opsat</h2>
        <p>Gå til <a href="?page=rzpa-settings">Indstillinger</a> og tilføj Access Token og Ad Account ID.</p>
      </div>`;
      return;
    }

    const spend  = parseFloat(s.total_spend) || 0;
    const clicks = parseInt(s.total_clicks) || 0;
    const impr   = parseInt(s.total_impressions) || 0;
    const ctr    = parseFloat(s.avg_ctr) || (impr > 0 ? Math.round(clicks/impr*10000)/100 : 0);
    const cpc    = parseFloat(s.avg_cpc) || (clicks > 0 ? Math.round(spend/clicks*100)/100 : 0);
    const perDay = days > 0 ? Math.round(spend / days) : 0;

    renderKPI('kpi_spend',  spend > 0 ? fmt(spend,0) + ' kr' : '–',
      perDay > 0 ? '≈ ' + fmt(perDay,0) + ' kr/dag' : 'Klik "Hent data" for at hente kampagner');
    renderKPI('kpi_impr',   fmt(impr));
    renderKPI('kpi_clicks', fmt(clicks), cpc > 0 ? fmt(cpc,2) + ' kr per klik' : '');
    renderKPI('kpi_ctr',    ctr > 0 ? fmt(ctr,2) + '%' : '–',
      ctr >= 1.5 ? '✅ Over gennemsnit' : ctr >= 0.5 ? '⚠️ Under målet (mål: 1,5%+)' : ctr > 0 ? '❌ Lav – overvej nyt kreativt indhold' : '');

    const expEl = el('meta-explain'), expTxt = el('meta-explain-text');
    if (expEl && expTxt && spend > 0) {
      expEl.style.display = 'flex';
      expTxt.textContent = `Du brugte ${fmt(spend,0)} kr og nåede ${fmt(impr)} folk – ${fmt(clicks)} klikkede videre. `
        + `Det svarer til ${fmt(cpc,2)} kr per klik og ${fmt(perDay,0)} kr per dag. `
        + (ctr >= 1.5 ? 'Annoncerne fanger godt opmærksomhed! 🚀'
          : ctr >= 0.5 ? 'Klikraten er okay – test nyt indhold for at forbedre den.'
          : ctr > 0 ? 'Klikraten er lav – prøv at ændre billede, overskrift eller målgruppe.'
          : '');
    } else if (expEl) expEl.style.display = 'none';

    // Performance oversigt
    const perfSum = el('meta-perf-summary');
    if (perfSum && metaAllData.length) {
      const good = metaAllData.filter(c=>(parseFloat(c.ctr)||0)>=1.5).length;
      const mid  = metaAllData.filter(c=>{const v=parseFloat(c.ctr)||0;return v>=0.5&&v<1.5;}).length;
      const bad  = metaAllData.filter(c=>(parseFloat(c.ctr)||0)<0.5).length;
      setText('perf_good_count',good); setText('perf_mid_count',mid); setText('perf_bad_count',bad);
      perfSum.style.display = 'flex';
    }

    const top6   = [...metaAllData].sort((a,b)=>b.spend-a.spend).slice(0,6);
    const labels = top6.map(c => c.campaign_name.replace(/Rezponz\s*[–-]\s*/i,'').slice(0,20));
    barChart('chart_spend', labels,
      [{data:top6.map(c=>Math.round(c.spend||0)),backgroundColor:'#1877F2',borderRadius:5}],
      {yTick: v => Math.round(v/1000)+'k kr'}
    );
    barChart('chart_ctr', labels,
      [{data:top6.map(c=>parseFloat(c.ctr||0)),
        backgroundColor:top6.map(c=>(parseFloat(c.ctr)||0)>=1.5?'#CCFF00':(parseFloat(c.ctr)||0)>=0.5?'#f5a623':'#cc4400'),
        borderRadius:5}],
      {yTick: v => v+'%'}
    );
    renderMetaTable(metaAllData);
  }

  // ════════════════════════════════════════════════════
  // PAGE: SNAPCHAT
  // ════════════════════════════════════════════════════

  async function initSnap() {
    let days = 30;
    initDateFilter('rzpa-date-filter', d => { days = d; loadSnap(d); });
    loadSnap(days);
    el('rzpa-sync-snap')?.addEventListener('click', async () => {
      await api('/snap/sync', { method: 'POST', body: JSON.stringify({days}) });
      loadSnap(days);
    });
  }

  async function loadSnap(days) {
    const [sum, camps] = await Promise.all([
      api(`/snap/summary?days=${days}`),
      api(`/snap/campaigns?days=${days}`),
    ]);
    const s = sum.data || {}, data = camps.data || [];

    if (s.configured === false) {
      const app = el('rzpa-app');
      if (app) app.innerHTML = `<div class="rzpa-not-configured">
        <h2>⚙️ Snapchat Ads er ikke opsat</h2>
        <p>Gå til <a href="?page=rzpa-settings">Indstillinger</a> og tilføj din Snapchat access token og ad account ID.</p>
      </div>`;
      return;
    }

    renderKPI('kpi_spend',      fmt(s.total_spend,0) + ' kr');
    renderKPI('kpi_swipes',     fmt(s.total_swipe_ups));
    renderKPI('kpi_impr',       fmt(s.total_impressions));
    renderKPI('kpi_engagement', fmt(s.avg_engagement_rate,2) + '%');

    const labels = data.slice(0,6).map(c => c.campaign_name.replace('Rezponz – ','').slice(0,20));
    barChart('chart_spend', labels,
      [{ data: data.slice(0,6).map(c=>Math.round(c.spend)), backgroundColor: '#FFFC00', borderRadius: 5 }]
    );
    barChart('chart_engagement', labels,
      [{ data: data.slice(0,6).map(c=>c.engagement_rate), backgroundColor: '#CCFF00', borderRadius: 5 }]
    );

    const tbody = el('snap_tbody');
    if (tbody) tbody.innerHTML = data.map(c => `
      <tr>
        <td style="color:#ddd;font-weight:500;max-width:200px;overflow:hidden;text-overflow:ellipsis">${c.campaign_name}</td>
        <td>${badgeHtml(c.status)}</td>
        <td>${fmt(c.spend,0)} kr</td>
        <td>${fmt(c.impressions)}</td>
        <td style="color:var(--neon);font-weight:700">${fmt(c.swipe_ups)}</td>
        <td>${fmt(c.conversions)}</td>
        <td>${fmt(c.cpm,2)} kr</td>
        <td>${fmt(c.engagement_rate,2)}%</td>
      </tr>`).join('');
  }

  // ════════════════════════════════════════════════════
  // PAGE: TIKTOK
  // ════════════════════════════════════════════════════

  async function initTikTok() {
    let days = 30;
    initDateFilter('rzpa-date-filter', d => { days = d; loadTikTok(d); });
    loadTikTok(days);
    el('rzpa-sync-tiktok')?.addEventListener('click', async () => {
      await api('/tiktok/sync', { method: 'POST', body: JSON.stringify({days}) });
      loadTikTok(days);
    });
  }

  async function loadTikTok(days) {
    const [sum, camps] = await Promise.all([
      api(`/tiktok/summary?days=${days}`),
      api(`/tiktok/campaigns?days=${days}`),
    ]);
    const s = sum.data || {}, data = camps.data || [];

    if (s.configured === false) {
      const app = el('rzpa-app');
      if (app) app.innerHTML = `<div class="rzpa-not-configured">
        <h2>⚙️ TikTok Ads er ikke opsat</h2>
        <p>Gå til <a href="?page=rzpa-settings">Indstillinger</a> og tilføj din TikTok access token og advertiser ID.</p>
      </div>`;
      return;
    }

    renderKPI('kpi_spend',  fmt(s.total_spend,0) + ' kr');
    renderKPI('kpi_views',  fmt(s.total_video_views));
    renderKPI('kpi_roas',   fmt(s.avg_roas,2) + 'x');
    renderKPI('kpi_clicks', fmt(s.total_clicks));

    const labels = data.slice(0,6).map(c => c.campaign_name.replace('Rezponz – ','').slice(0,22));
    barChart('chart_views', labels,
      [{ data: data.slice(0,6).map(c=>c.video_views), backgroundColor: '#ff0050', borderRadius: 5 }],
      { yTick: v => (v/1000).toFixed(0)+'k' }
    );
    barChart('chart_roas', labels,
      [{ data: data.slice(0,6).map(c=>c.roas),
         backgroundColor: data.slice(0,6).map(c => c.roas>=2.5?'#CCFF00':c.roas>=1.5?'#88cc00':'#cc4400'),
         borderRadius: 5 }]
    );

    const tbody = el('tiktok_tbody');
    if (tbody) tbody.innerHTML = data.map(c => `
      <tr>
        <td style="color:#ddd;font-weight:500;max-width:200px;overflow:hidden;text-overflow:ellipsis">${c.campaign_name}</td>
        <td>${badgeHtml(c.status)}</td>
        <td>${fmt(c.spend,0)} kr</td>
        <td>${fmt(c.video_views)}</td>
        <td>${fmt(c.clicks)}</td>
        <td>${fmt(c.conversions)}</td>
        <td class="${roasClass(c.roas)}">${fmt(c.roas,2)}x</td>
        <td>${fmt(c.cost_per_view,4)} kr</td>
      </tr>`).join('');
  }

  // ════════════════════════════════════════════════════
  // PAGE: RAPPORT
  // ════════════════════════════════════════════════════

  async function initRapport() {
    el('rzpa-gen-rapport')?.addEventListener('click', async () => {
      const btn    = el('rzpa-gen-rapport');
      const notice = el('rzpa-rapport-notice');
      const days   = parseInt(document.querySelector('[data-days].active')?.dataset.days || 30);

      btn.disabled = true;
      btn.textContent = 'Genererer…';

      try {
        const r = await api('/pdf/generate', {
          method: 'POST',
          body: JSON.stringify({ days }),
        });

        if (r.success && r.html) {
          // Brug Blob URL for at undgå popup-blocker
          const blob = new Blob([r.html], { type: 'text/html;charset=utf-8' });
          const url  = URL.createObjectURL(blob);
          const win  = window.open(url, '_blank');
          if (win) {
            win.addEventListener('load', () => {
              setTimeout(() => { win.print(); URL.revokeObjectURL(url); }, 800);
            });
            notice.className = 'rzpa-notice success';
            notice.textContent = 'Rapport åbnet i nyt vindue – brug Ctrl+P / Cmd+P til at gemme som PDF.';
          } else {
            // Popup blev blokeret – tilbyd download i stedet
            const a = document.createElement('a');
            a.href = url; a.download = 'rezponz-rapport.html'; a.click();
            notice.className = 'rzpa-notice success';
            notice.textContent = 'Rapport downloadet som HTML – åbn filen og tryk Ctrl+P for at gemme som PDF.';
          }
          notice.style.display = 'block';
        }
      } catch(e) {
        notice.className = 'rzpa-notice error';
        notice.textContent = 'Fejl: ' + e.message;
        notice.style.display = 'block';
      } finally {
        btn.disabled = false;
        btn.textContent = 'Generer & Åbn Rapport';
      }
    });

    initDateFilter('rzpa-date-filter', () => {});
  }

  // ── Auto-init ──────────────────────────────────────

  document.addEventListener('DOMContentLoaded', () => {
    const page = document.getElementById('rzpa-app')?.dataset?.rzpaPage;
    const initMap = {
      dashboard: initDashboard,
      seo:       initSEO,
      ai:        initAI,
      meta:      initMeta,
      snap:      initSnap,
      tiktok:    initTikTok,
      rapport:   initRapport,
    };
    if (initMap[page]) initMap[page]();
  });

  // Public API (used inline)
  return { loadKwTrend, deleteLog };

})();
